import re

functionAddress = ""
functionString = ""
insideFunction = 0

with open("eqgame.c", "rt") as in_file:
    lines = in_file.readlines()
    for index, line in enumerate(lines):

        if line == "{\n":
            insideFunction = 1

        if line == "}\n":
            insideFunction = 0

        if line.find("//----- (") != -1:
            matches = re.findall("([0-9A-F]+)", line)
            if matches:
                functionAddress = "0x" + matches[0]
                # print(functionAddress)

        if insideFunction == 1:

            functionString += line

        if insideFunction == 0:

            # CollisionCallbackForActors
            if functionString.find("v1 = (*(int (__thiscall **)(int))(*(_DWORD *)a1 + 32))(a1);") != -1:
                if functionString.find("v2 = (*(int (__thiscall **)(int))(*(_DWORD *)a1 + 48))(a1);") != -1:
                    if functionString.find("v3 = (*(int (__thiscall **)(int))(*(_DWORD *)v1 + 12))(v1);") != -1:
                        if functionString.find("v4 = (_BYTE *)(*(int (__thiscall **)(int))(*(_DWORD *)v3 + 68))(v3);") != -1:
                            print("CollisionCallbackForActors = " + functionAddress)
                            functionAddress = ""

            # DoSpellEffect
            if re.search("if \( \!a\d+ \|\| \!a\d+ \|\| \!a\d+ \|\| \!\*a\d+ \&\& \!a\d+\[\d+\] \|\| a\d+ \> 2 \)", functionString):
                print("DoSpellEffect = " + functionAddress)
                functionAddress = ""

            # WindowProc
            if functionString.find("return DefWindowProcA(hWnd") != -1:
                print("WindowProc = " + functionAddress)
                functionAddress = ""

            # CBazaarSearchWnd__AddItemToList
            if re.search("v\d+ = this\[9358\];", functionString):
                if re.search("if \( v\d+ \< 200 \)", functionString):
                    print("CBazaarSearchWnd__AddItemToList = " + functionAddress)
                    functionAddress = ""

            # CBazaarSearchWnd__BuyItem
            if re.search("v\d+ = this\[152\];", functionString):
                if re.search("if \( v\d+ \< 0 \|\| v\d+ \>\= 200 \|\| \!dword_", functionString):
                    print("CBazaarSearchWnd__BuyItem = " + functionAddress)
                    functionAddress = ""

            # CBazaarSearchWnd__doQuery
            if functionString.find("&aBuylineslist") != -1:
                print("CBazaarSearchWnd__doQuery = " + functionAddress)
                functionAddress = ""

            # CEverQuest__HandleMouseWheel
            if functionString.find(" * 0.2 * 90.0 + 10.0;") != -1:
                print("CEverQuest__HandleMouseWheel = " + functionAddress)
                functionAddress = ""

            # CEverQuest__StartCasting
            if functionString.find("%s <%s>") != -1:
                print("CEverQuest__StartCasting = " + functionAddress)
                functionAddress = ""

            # EQSwitch__ChangeState
            if functionString.find("!= 57") != -1:
                if functionString.find("!= 58") != -1:
                    if functionString.find("!= -97") != -1:
                        if functionString.find("!= -96") != -1:
                            if functionString.find("!= -95") != -1:
                                print("EQSwitch__ChangeState = " + functionAddress)
                                functionAddress = ""

            functionString = ""