import re

functionAddress = ""
functionString = ""
insideFunction = 0

with open("eqgame.c", "rt") as in_file:
    lines = in_file.readlines()
    for index, line in enumerate(lines):

        if line == "{\n":
            insideFunction = 1

        if line == "}\n":
            insideFunction = 0

        if line.find("//----- (") != -1:
            matches = re.findall("([0-9A-F]+)", line)
            if matches:
                functionAddress = "0x" + matches[0]
                # print(functionAddress)

        if insideFunction == 1:

            functionString += line

        if insideFunction == 0:

            # CollisionCallbackForActors
            if functionString.find("v1 = (*(int (__thiscall **)(int))(*(_DWORD *)a1 + 32))(a1);") != -1:
                if functionString.find("v2 = (*(int (__thiscall **)(int))(*(_DWORD *)a1 + 48))(a1);") != -1:
                    if functionString.find("v3 = (*(int (__thiscall **)(int))(*(_DWORD *)v1 + 12))(v1);") != -1:
                        if functionString.find("v4 = (_BYTE *)(*(int (__thiscall **)(int))(*(_DWORD *)v3 + 68))(v3);") != -1:
                            print("CollisionCallbackForActors = " + functionAddress)
                            functionAddress = ""

            # DoSpellEffect
            if re.search("if \( \!a\d+ \|\| \!a\d+ \|\| \!a\d+ \|\| \!\*a\d+ \&\& \!a\d+\[\d+\] \|\| a\d+ \> 2 \)", functionString):
                print("DoSpellEffect = " + functionAddress)
                functionAddress = ""

            # FlushDxKeyboard
            if re.search("\w+\d+ \= 32;", functionString):
                if functionString.find("__stdcall") != -1:
                    if re.search("dword_[0-9A-F]+ \+ 40", functionString):
                        if functionString.find("20,") != -1:
                            if re.search("dword_[0-9A-F]+ \= 0;", functionString):
                                if re.search("byte_[0-9A-F]+ \= 0;", functionString):
                                    if re.search("if \( dword_[0-9A-F]+ \)", functionString):
                                        if re.search("sub_[0-9A-F]+\(dword_[0-9A-F]+\);", functionString):
                                            print("FlushDxKeyboard = " + functionAddress)
                                            functionAddress = ""

            # FlushDxMouse
            if re.search("\w+\d+ \= 128;", functionString):
                if functionString.find("__stdcall") != -1:
                    if re.search("dword_[0-9A-F]+ \+ 40", functionString):
                        if functionString.find("20,") != -1:
                            if functionString.find(">= 0 ? 1 : 7;") != -1:
                                if re.search("dword_[0-9A-F]+ \+ 7;", functionString):
                                    print("FlushDxMouse = " + functionAddress)
                                    functionAddress = ""

            # get_bearing
            if functionString.find("fabs") != -1:
                if functionString.find("atan2") != -1:
                    if functionString.find("0.0000009999999974752427") != -1:
                        if functionString.find(" * 180.0 * 0.3183099014828645;") != -1:
                            if functionString.find(" + 90.0) * 511.5 * 0.0027777778;") != -1:
                                if functionString.find(" + 180.0) * 511.5 * 0.0027777778;") != -1:
                                    if functionString.find(" * 511.5 * 0.0027777778;") != -1:
                                        if functionString.find(" + 270.0) * 511.5 * 0.0027777778;") != -1:
                                            print("get_bearing = " + functionAddress)
                                            functionAddress = ""

            # get_melee_range
            if functionString.find("return 14.0") != -1:
                if functionString.find("== -572662307") != -1:
                    if functionString.find("> 286331153") != -1:
                        if functionString.find("< 14.0") != -1:
                            if functionString.find("= 14.0") != -1:
                                if functionString.find("> 75.0") != -1:
                                    if functionString.find("= 75.0") != -1:
                                        print("get_melee_range = " + functionAddress)
                                        functionAddress = ""

            # ProcessKeyboardEvent
            if functionString.find("GetForegroundWindow()") != -1:
                if functionString.find("!= hwnd") != -1:
                    if functionString.find("GetAsyncKeyState(16) & 0x8000") != -1:
                        if functionString.find("GetAsyncKeyState(17) & 0x8000") != -1:
                            if functionString.find("GetAsyncKeyState(18) & 0x8000") != -1:
                                    print("ProcessKeyboardEvent = " + functionAddress)
                                    functionAddress = ""

            # ProcessMouseEvent    # 0x2F3Fu
            if functionString.find("GetForegroundWindow()") != -1:
                if functionString.find("== hwnd") != -1:
                    #if functionString.find("0x2F3Fu") != -1:
                        if functionString.find("ShowCursor(1)") != -1:
                            if functionString.find("ClientToScreen") != -1:
                                if functionString.find("SetCursorPos(Point.x, Point.y);") != -1:
                                    print("ProcessMouseEvent = " + functionAddress)
                                    functionAddress = ""

            # WindowProc
            if functionString.find("return DefWindowProcA(hWnd") != -1:
                print("WindowProc = " + functionAddress)
                functionAddress = ""

            # CBazaarSearchWnd__AddItemToList
            if re.search("\w+\d+ = this\[9358\];", functionString):
                if re.search("if \( \w+\d+ \< 200 \)", functionString):
                    print("CBazaarSearchWnd__AddItemToList = " + functionAddress)
                    functionAddress = ""

            # CBazaarSearchWnd__BuyItem
            if re.search("\w+\d+ = this\[152\];", functionString):
                if re.search("if \( \w+\d+ \< 0 \|\| \w+\d+ \>\= 200 \|\| \!dword_", functionString):
                    print("CBazaarSearchWnd__BuyItem = " + functionAddress)
                    functionAddress = ""

            # CBazaarSearchWnd__doQuery
            if functionString.find("&aBuylineslist") != -1:
                print("CBazaarSearchWnd__doQuery = " + functionAddress)
                functionAddress = ""

            # CEverQuest__HandleMouseWheel
            if functionString.find("fabs") != -1:
                if functionString.find(" * 0.2 * 90.0 + 10.0;") != -1:
                    print("CEverQuest__HandleMouseWheel = " + functionAddress)
                    functionAddress = ""

            # CDisplay__CreateActor
            if functionString.find("PLAYER_1") != -1:
                if functionString.find("BBBOARD") != -1:
                    print("CDisplay__CreateActor = " + functionAddress)
                    functionAddress = ""

            # CDisplay__CreatePlayerActor
            if functionString.find("CDisplay::CreatePlayerActor - FATAL ERROR") != -1: # "OBP_SPELLTREE_ACTORDEF"
                print("CDisplay__CreatePlayerActor = " + functionAddress)
                functionAddress = ""

            # CDisplay__DeleteActor
            if re.search("\(\*\(void \(__stdcall \*\*\)\(int\)\)\(\*\(_DWORD \*\)dword_[0-9A-F]+ \+ 108\)\)\(\w+\d+\);", functionString):
                if functionString.find(", 0, 1);") != -1:
                    if functionString.find(", 0);") != -1:
                        print("CDisplay__DeleteActor = " + functionAddress)
                        functionAddress = ""

            # CEverQuest__StartCasting
            if functionString.find("%s <%s>") != -1:
                if functionString.find(", 0, 500);") != -1:
                    if functionString.find(", 99);") != -1:
                        print("CEverQuest__StartCasting = " + functionAddress)
                        functionAddress = ""

            # EQPlayer__FollowPlayerAI    # 0x3194u, 0x3195u
            if functionString.find("> 200.0") != -1:
                if functionString.find(">= 20.0") != -1:
                    if functionString.find("+ 15.0 <=") != -1:
                        if functionString.find("+ 30.0 <=") != -1:
                                print("EQPlayer__FollowPlayerAI = " + functionAddress)
                                functionAddress = ""

            # EQPlayer__UpdateItemSlot
            if functionString.find("IT36") != -1:
                if functionString.find("IT159") != -1:
                    if functionString.find("IT10758") != -1:
                        if functionString.find("IT10742") != -1:
                                print("EQPlayer__UpdateItemSlot = " + functionAddress)
                                functionAddress = ""

            # EQSwitch__ChangeState
            if functionString.find("!= 57") != -1:
                if functionString.find("!= 58") != -1:
                    if functionString.find("!= -97") != -1:
                        if functionString.find("!= -96") != -1:
                            if functionString.find("!= -95") != -1:
                                print("EQSwitch__ChangeState = " + functionAddress)
                                functionAddress = ""

            functionString = ""