function OnDrawHUD()
    return 1, "- Combat State: " .. EQ_PlayerWindow_GetCombatState()
end
