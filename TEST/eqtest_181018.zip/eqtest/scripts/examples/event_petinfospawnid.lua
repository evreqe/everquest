function OnDrawHUD()
    return 1, "- Pet Spawn ID: " .. EQ_PetInfoWindow_GetSpawnID()
end
