function OnEnterZone(zoneID)

    EQ_InterpretCommand("//CombatHotButton 4")
    EQ_InterpretCommand("//CombatHotButtonOn")

end
