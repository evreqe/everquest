function OnChatText(chatText, chatTextColor)
    EQAPP_Log(chatTextColor .. "^" .. chatText)
end
