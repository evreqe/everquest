function OnTick()

    EQ_PrintTextToChat("Tick!")

end
