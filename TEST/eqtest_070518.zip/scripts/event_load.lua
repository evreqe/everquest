function OnLoad()
    EQ_InterpretCommand("/outputfile inventory")
end