function OnEnterZone(zoneID)
    EQ_InterpretCommand("/outputfile inventory")
end
