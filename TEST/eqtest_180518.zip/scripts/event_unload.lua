function OnUnload()
    EQ_InterpretCommand("/outputfile inventory")
end