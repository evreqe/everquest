-- draw text test
function OnDrawNetStatus()

    EQ_DrawText("OnDrawNetStatus() test text", 100, 100)

end

function OnDrawWindows()

    EQ_DrawTextEx("OnDrawWindows() test text", 200, 200, EQ_DRAW_TEXT_COLOR_RED)

end
